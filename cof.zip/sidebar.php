<?php
/**
 * The template for displaying sidebar.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package COF
 */

?>
<div id="sidebar-primary" class="sidebar">
    <?php dynamic_sidebar( 'wc-sidebar' ); ?>
</div>
