<?php
/**
 * The template for displaying all single case study page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package COF
 */

get_header();

	get_template_part( 'template-parts/content', 'single' );

get_footer();
